from flask import Flask,Response, render_template, request, jsonify

import cv2
import mediapipe as mp
import time
app = Flask(__name__)

# ====== MEDIA PIPELINE SETUP ======
mp_hands = mp.solutions.hands
hands = mp_hands.Hands(max_num_hands=2, min_detection_confidence=0.7)
mp_drawing = mp.solutions.drawing_utils

# ====== VIDEO CAPTURE ======
cap = cv2.VideoCapture(0)
prev_actions = [None, None]
last_action_times = [0, 0]


# ====== VALID GESTURES ======
VALID_GESTURES = {
    (0,0,0,0,0): 'forward',
    (0,1,1,0,0): 'backward',
    (0,1,1,1,0): 'tank_left',
    (0,1,1,1,1): 'tank_right',
    (1,1,1,1,1): 'stop',
    (1,0,0,0,1): 'crab_right',
    (0,1,0,0,1): 'rotate_cw',
    (0,1,1,0,1): 'rotate_ccw',
    (0,1,0,1,0): 'fwd_left',
    (0,1,0,1,1): 'fwd_right',
    (0,1,1,0,0): 'bwd_left',
    (0,1,1,0,1): 'bwd_right',
    (1,1,0,0,0): 'soft_left',
    (1,1,1,0,0): 'soft_right'
}

# Recognize a gesture based on hand landmarks
def recognize_gesture(hand_landmarks):
    tip_ids = [4, 8, 12, 16, 20]
    fingers = [0] * 5
    # Thumb
    fingers[0] = 1 if hand_landmarks.landmark[4].x < hand_landmarks.landmark[3].x else 0
    # Other four fingers
    for i in range(1, 5):
        fingers[i] = 1 if hand_landmarks.landmark[tip_ids[i]].y < hand_landmarks.landmark[tip_ids[i] - 2].y else 0
    return VALID_GESTURES.get(tuple(fingers), None)

# Generate video frames with gesture overlay
def generate_frames():
    global prev_actions, last_action_times

    while True:
        success, frame = cap.read()
        if not success:
            break

        frame = cv2.flip(frame, 1)  # Flip horizontally to create mirror image
        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        results = hands.process(rgb)

        gesture_text = None
        if results.multi_hand_landmarks:
            for idx, landmarks in enumerate(results.multi_hand_landmarks):
                mp_drawing.draw_landmarks(frame, landmarks, mp.solutions.hands.HAND_CONNECTIONS)
                gesture = recognize_gesture(landmarks)
                if gesture and (gesture != prev_actions[idx % 2] or time.time() - last_action_times[idx % 2] > 1):
                    prev_actions[idx % 2] = gesture
                    last_action_times[idx % 2] = time.time()
                    gesture_text = gesture

        # Overlay detected gesture text
        if gesture_text:
            cv2.putText(frame,
                        f"Detected: {gesture_text}",
                        (10, 30),
                        cv2.FONT_HERSHEY_SIMPLEX,
                        1,
                        (0, 255, 0),
                        2,
                        cv2.LINE_AA)

        # Encode frame as JPEG
        ret, buffer = cv2.imencode('.jpg', frame)
        frame_bytes = buffer.tobytes()

        # Yield frame in HTTP multipart format
        yield (b'--frame\r\n'
               b'Content-Type: image/jpeg\r\n\r\n' + frame_bytes + b'\r\n')

# ====== FLASK ROUTES ======
@app.route('/gesture')
def gesture():
    # Serve the HTML UI
    return render_template('gesture_main.html')

@app.route("/")
def index():
    return render_template("manual.html")

# Manual Fetching

@app.route("/key-pressed", methods=["POST"])
def key_pressed():
    data = request.get_json()
    key = data.get("key")
    print(f"Key pressed: {key}")
    return jsonify({"message": f"Key {key} received!"})

# video Fetching

@app.route('/video_feed')
def video_feed():
    # Stream video frames
    return Response(generate_frames(),
                    mimetype='multipart/x-mixed-replace; boundary=frame')

if __name__ == "__main__":
    app.run(debug=True)
